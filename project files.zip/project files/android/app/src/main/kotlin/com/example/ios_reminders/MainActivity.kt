package com.example.ios_reminders

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
